package com.ats.technicalscreen.ishappyprime;

import org.junit.Test;

public class IsHappyPrimeTest {

	@Test
	public void sampleTest() {
		// TODO: implement tests
		System.out.println("\n*** HAPPY_PRIME TESTS STARTING***");
		IsHappyPrime ihp = new IsHappyPrime(); 
		//
		// throw together some easy quick-and-dirty tests
		// 7, 13, 19, 23, 31, 79, 97, 103, 109, 139
		//
		// could also come up w/random number generator tests
		//
		int[] intArray = {0,1,2,3,4,5,6,7,8,9,10,11,13,14,15,17,19,23,31,32,97,99,139,440,400087,400089};
		for ( int n : intArray) {
			System.out.print("\t");
			System.out.print( (ihp.isHappyPrime( n)) ? (n + " is ") : ("\t" + n + " is not "));
			System.out.println("a Happy Prime number.");
		}
		//
		System.out.println("\n*** HAPPY_PRIME TESTS DONE ***");
	}
}
