package com.ats.technicalscreen.arraycontainsduplicates;

import org.junit.Test;

public class ArrayContainsDuplicatesTest {

	@Test
	public void sampleTest() {
		// TODO: implement tests
		System.out.println("\n*** ARRAY DUPE TESTS STARTING***");
		ArrayContainsDuplicates acd = new ArrayContainsDuplicates(); 
		//
		// throw together some easy quick-and-dirty tests
		// - test low condition, i.e., too small to contain dupes
		// - test dupe condition
		// - test no dupe condition
		//
		// additional tests can be added 
		//	e.g., null pointer, string array, really large array
		//
		// since no customer requirements were provided to take into account
		// memory utilization, efficiency, spped, etc - this was a quick solution
		//
		int[] smallArray = {0,1};
		if ( acd.containsDuplicates(smallArray)) {
			System.out.println("\t*** Duplicates Removed ***");
		}
		else
		{
			System.out.println("\t*** NO DUPLICATES ***");
		}
		//
		System.out.println("\n*** ***");
		int[] dupesArray = {0,1,2,3,4,4};
		if ( acd.containsDuplicates(dupesArray)) {
			System.out.println("\t*** Duplicates Removed ***");
		}
		else
		{
			System.out.println("\t*** NO DUPLICATES ***");
		}
		//
		//
		System.out.println("\n*** ***");
		int[] noDupesArray = {0,1,2,3,4};
		if ( acd.containsDuplicates(noDupesArray)) {
			System.out.println("\t*** Duplicates Removed ***");
		}
		else
		{
			System.out.println("\t*** NO DUPLICATES ***");
		}
		//
		System.out.println("\n*** ARRAY DUPE TESTS DONE ***");
	}
}
