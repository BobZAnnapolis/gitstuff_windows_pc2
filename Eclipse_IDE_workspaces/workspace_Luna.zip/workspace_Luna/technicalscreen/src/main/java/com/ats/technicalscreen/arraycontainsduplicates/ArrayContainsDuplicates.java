package com.ats.technicalscreen.arraycontainsduplicates;

import java.util.*;

public class ArrayContainsDuplicates {

	/**
	 * This method determines whether the input array contains any duplicate integers.
	 *
	 * TODO: The algorithmic complexity of my solution is ____ .
	 *
	 * @param input the input array
	 * @return Whether the array contains duplicates
	 *  
	 */
	public boolean containsDuplicates(int[] input) {
		// 
		// TODO: 
		//     Efficiently determine whether the input array contains any duplicate values. 
		//     You may use java data structures in java.util.*  
		//
		// any array that has 0 or 1 elements in it cannot contain dupes so
		// if the input array meets this criteria, return false
		//
		if ( input.length <= 2) {
			System.out.println("Input array not big enough to contain dupes. Size : " + input.length);
			return false;
		}
		//
		// once here, we have an array with 2 or more elements
		// use the Java "set" data structure which does NOT allow dupes
		// - move the input array into the set, 
		// - compare sizes of input array and created set
		// - if not equal, dupes were removed - return true - else return false
		//
		System.out.println("Input array size = " + input.length);
		Set<Integer> set = new HashSet<Integer>();
        for (int val : input)
               set.add(val);
		
		System.out.println("Converted set size = " + set.size());
		if ( input.length != set.size()) {
			return true;
		}		
		return false;
	}
}
