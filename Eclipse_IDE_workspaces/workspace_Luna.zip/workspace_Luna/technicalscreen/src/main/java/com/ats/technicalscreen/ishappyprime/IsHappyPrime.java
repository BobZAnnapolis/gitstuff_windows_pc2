package com.ats.technicalscreen.ishappyprime;

/**
 * ===== Happy Primes ======
 * Background:
 * In the 2007 Doctor Who episode "42", a sequence of happy primes (313, 331, 367, 379) is used as a code for 
 * unlocking a sealed door on a spaceship about to collide with a star. When the Doctor learns that nobody 
 * on the spaceship besides himself has heard of happy numbers, he asks, "Don't they teach recreational 
 * mathematics anymore?"
 *  
 * Happy Prime Definition:
 *    A happy prime is a number that is both 'prime' and 'happy'
 *  
 * Happy Number Definition:  
 *    A 'happy' number is defined by the following process - starting with any positive integer, replace the number 
 *    by the sum of the squares of its digits, and repeat the process until the number equals 1 (where it will stay), 
 *    or it loops endlessly in a cycle which does not include 1.
 * 
 * Happy Number Examples: 
 * a) 19 is happy
 *    19    
 *    1^2 + 9^2 = 82
 *    8^2 + 2^2 = 68
 *    6^2 + 8^2 = 100
 *    1^2 + 0^2 + 0^2 = 1 ===> Happy!!!! :-)
 *    
 * b) 4 is not happy (and results in a cycle)
 *    4
 *    4^2 = 16
 *    1^2 + 6^2 = 37
 *    3^2 + 7^2 = 58 
 *    5^2 + 8^2 = 89
 *    8^2 + 9^2 = 145
 *    1^2 + 4^2 + 5^2 = 42
 *    4^2 + 2^2 = 20
 *    2^2 + 0^2 = 4 ===> Cycle!!! Not Happy :-(
 * 
 */
public class IsHappyPrime {

	/**
	 * Determines whether the input value is a "happy prime" 
	 * e.g., a prime number that is also a happy number
	 * 
	 * @param input The input value
	 * @return Whether the input value is a happy prime
	 */
	boolean isHappyPrime(int input) {
		
		/**
		 * there are 2 criteria to be checked for, prime and "happy"
		 * farm off the actual work to local private methods
		 */
		if ( ! isPrime(input)) {
			return false;
		}
		if ( ! isHappy(input)) {
			return false;
		}
		return true;
	}
	
	/**
	 * determines whether the input number is prime
	 * uses one of the many "is this number a prime" methods
	 * available on the net
	 */
	private boolean isPrime(int p_nVal) {
		//
		// most math sites say that 1 is not a prime so add that test
		// 
		if (p_nVal <= 1) return false;
		//
		// lots of different solutions avlbl, had to pick one
		// i liked the one that checked to see if the number
		//   was divisible by 2 first but went with this one
		//
		int sqrt = (int) Math.sqrt(p_nVal) + 1;
        for (int i = 2; i < sqrt; i++) {
            if (p_nVal % i == 0) {
                // number is perfectly divisible - no prime
                return false;
            }
        }
        return true;
	}
	/**
	 * determines whether the input number is happy
	 * implement above algorithm
	 *
	 * looked on Wiki for a definition, then online 
	 * for a variety of solutions
	 * it's a mathematical algorithm to determine the answer
	 *      i'm not going to re-invent the wheel, it has to do
	 *      with recursion, 10s getting back to 1, etc 
	 *      - other people have provided solutions, use theirs
	 */
	private boolean isHappy(int p_nVal) {
		//
		int a = sum_sq_digits(p_nVal);
		while (a > 9) {
			a = sum_sq_digits(a);
		}
		if (a == 1)
			return true;
		else
			return false;
	}

	// process each digit
	private int sum_sq_digits(int p_nDigit) {
		if (p_nDigit == 0)
			return 0;
		else {
			int d = p_nDigit % 10;
			return (d * d + sum_sq_digits(p_nDigit / 10));
		}
	}

}