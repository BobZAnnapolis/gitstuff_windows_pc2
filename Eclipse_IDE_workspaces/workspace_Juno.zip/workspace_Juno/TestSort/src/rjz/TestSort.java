package rjz;

import java.util.Arrays;
/*
 * Sample program to sort an array
 * 
 * Problem : Given a mixed array of numbers and alphanumeric terms, please implement a 
 * function \ method that will return a sorted array such that the numbers are in numeric 
 * order, and the alphanumeric terms are in alphabetical order subject to the following 
 * constraints:
 * 
 * [1] For any index n in the array, the type of value at index n must be the same in the input 
 * and result arrays � e.g., given the input array { 12, beta, 10, alpha } the 
 * positions (0, 2) are numeric, while the positions (1, 3) are alphanumeric, so the sorted 
 * result should be { 10, alpha, 12, beta }.
 * 
 * [2] The maximum size of the input array is 1,000,000 items.
*/
public class TestSort {

	// define constraint max size
	private final static int MAX_ARRAY_SIZE = 1000000;

	// implement the method to handle the sorting
	public static String[] sortMixedArray(String[] p_InputArray) {	
		// add a test for one of the constraints 
		int inputLen = p_InputArray.length;
		// added extra int var so i could test during debugging
		if (inputLen > MAX_ARRAY_SIZE) {
			// plenty of ways to handle this differently too
			System.out.println("\nMAX ALLOWED DATA SET SIZE IS " + MAX_ARRAY_SIZE);
			System.out.println("YOUR INPUT ITEM HAS " + inputLen);
			System.out.println("Program stopping - Please check data set and try again");
			System.exit(-1);
		}

		// if we get here, we have a data set length we allow
		// so output some diagnostic information
		System.out.println("\nSize of input array : \n" + p_InputArray.length);

		// create the array to return
		String[] retArray = new String[ inputLen];
		System.out.println("Size of array to return: \n" + retArray.length); // visually verify sizes match

		// once here, more time would be needed [for me] to think about all the possible 
		// input permutations of numbers & strings and come up with a decent algorithm that 
		// handled (number, number, string,....) or (str, str, num, num, str, num, num, num, str, str...)
		// etc - it wasn't clear from the instructions that the input set would always follow a
		// simple num/string/num/string.... pattern so...
		// ....i would write something here which would detect & preserve the originally input pattern,
		// then i would separate out the numbers and strings into separate arrays, sort them, then
		// use the preserved pattern to move the sorted vals back into the array being returned	
		
		// the following simple sort doesn't take into account the different types of vals at index locations
		// i ran out of time - but it's here where that "magic" would have happened
		Arrays.sort(p_InputArray);
		System.arraycopy(p_InputArray, 0, retArray, 0, inputLen);
		
		// also, it was mentioned in the instructions about things like efficiency - could use either the 
		// IDE to profile the code to determine how to make it better - or, if we had studies indicating
		// that 90% of the time it would be against data sets with only 100 elements - we could decide on
		// different data structures - i'd personally like to put more time into getting more information
		// about the data set coming in, the environment it is going to be used in, issues like that before
		// settling on 1 approach. And documenting why choices were made.
		//
		// That is, if any of that is even necessary, maybe this is just meant to be used as a utility
		// to help someone in which case, not that much time / thought should be put into it.
		
		return retArray;
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// for quick testing purposes - i'm using a small statically built array
		// given more time, once the sorting functionality was implemented
		// i would change the creation of the input array to sort to come from 
		// a few different methods, e.g., a file, a db table, random generator, etc 
		String names[] = {"12", "beta", "10", "alpha"};

		// print some "before" diagnostics
		System.out.println("Original Order : \n");
		for (int i = 0; i < names.length; i++) {
			System.out.println((i+1) + ": " + names[i]);
		}

		// there's a check in the method for the max_size constraint,
		// we could just as easily have put that check here, or,
		// called a method to handle constraint checking, or, 
		// created a class and used it
		
		// let's do the sort
		String[] aNewOrder = sortMixedArray(names);
		
		// show some "proof" of the sorting method
		System.out.println("\nNew Order : \n");
		for (int ii = 0; ii < aNewOrder.length; ii++) {
			System.out.println((ii+1) + ": " + aNewOrder[ii]);
		}
		// given more time - could add timing diagnostics - which would
		// be useful for large data sets ; memory resource usage, etc
	}
}
