package cspid;

/* *************************************************************************************
 * 
 * CSPid.java
 * @author Azi Siner / Robert John Zawislak
 * Modification History
 * 		OCT 11, 2012	rjz		Handed over to me, project personnel change
 * 								(1) as of this date, discovered that we have to 
 * 									use the 32-bit version of the Windows Java 
 * 									JDK/JRE & IDEs - PKCS11 jars not avlbl in 
 * 									64-bit version yet :-(
 * 								(2) changed original version member naming 
 * 									conventions a little to more easily identify
 * 									local, global & parameters
 * 		JUN 07, 2012	as		Initial Version
 * 
 * *************************************************************************************
 *
 * This class contains code to :
 * 	1) dynamically register and unregister a CSPid PKCS11 provider
 *  2) list the CSPid provider services, algorithms, certs & keys
 *  3) get specific key pairs for encryption & decryption
 *  4) generate an AES Secret key
 *  5) encrypt (wrap) the Secret key using the COI public key
 *  6) create a file and add the wrapped Secret key; encrypt a document and
 *            add it to the file, then add a tag containing the length of the key
 *  7) send the wrapped key to the Document Access Server (DAS) while
 *          send back the unwrapped key
 *  8) use the returned key to decrypt the encrypted COI document
 *  
 *  For this code to work, the wrapped key MUST be the first item in
 *  the file. Next comes the encrypted document. The tag must be the
 *  LAST item in the file.
 *  
 *  This class can be broken up into two {or more} classes, one for
 *  encryption and one for decryption.
 *  
 * *************************************************************************************/

import java.io.*;
import java.security.*;
import java.security.cert.*;
import java.security.Provider.*;
import java.security.spec.*;
import java.util.*;
import javax.crypto.*;
import javax.crypto.spec.*;

/* *********************************************************************************** */

public class CSPid {
	/*
	 * 
	 */
	public static boolean g_bEncrypting;
	public static String g_inFileName;
	public static String g_inCoiAlias;
	public static String g_inDrive;

	java.security.cert.Certificate g_cert = null;
	PrivateKey g_coiPrivateKey;
	PublicKey g_coiPublicKey;
	public static Provider g_pkcs11Provider = null;

	/*
	 * move all the strings to a 'properties' file, have init processing load
	 * them up
	 */
	public static String g_conf = "\\CSPid\\java_pkcs11.cfg";

	public static String AES_ALGO_PROPERTY = "aesAlgo";
	public static String RSA_ALGO_PROPERTY = "rsaAlgo";

	public static String AES_SECRET_KEY = "AES";

	public static String BIT_32 = "32";
	public static String DLL_32 = "CDK7060S.dll";
	public static String DLL_64 = "32";
	public static String HOME_DIR = "CSPID";
	public static String ENCRYPT_DIR = "ENCRYPT";
	public static String DECRYPT_DIR = "DECRYPT";

	public static String ENCRYPT_MODE = "ENCRYPT";
	public static String DECRYPT_MODE = "DECRYPT";
	public static String ENCRYPT_SUFFIX = ".enc";

	public static String PKCS11_KEYSTORE = "PKCS11";
	public static String PROPERTIES_FILE = "CSPid.properties";
	public static String PROVIDER_SUFFIX = "CSPid";
	public static String SUN_ARCH_DATA_MODEL = "sun.arch.data.model";
	public static String SUNPKCS11 = "SunPKCS11-";

	public static String USAGE = "Usage: mode file_path COI_alias drive_letter\n"
			+ "\tmode           ENCRYPT or DECRYPT\n"
			+ "\tfile_path      absolute path to file being encrypted or decrypted\n"
			+ "\t                  if mode = DECRYPT, file must end in : "
			+ ENCRYPT_SUFFIX
			+ "\n"
			+ "\tCOI_alias      COI certificate used to encrypt/decrypt\n"
			+ "\tdrive_letter   valid drive letter where CSPID is installed, e.g. C:";

	public CSPid() {
		; // tbd
	}

	/**
	 * utility function to read a Properties file
	 * 
	 * @return: properties list
	 */
	public Properties getProps() {
		Properties props = new Properties();
		try {
			String propertiesFile = File.separator + HOME_DIR + File.separator
					+ PROPERTIES_FILE;
			props.load(new FileInputStream(propertiesFile));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return props;
	}

	/*
	 * dynamically remove a provider
	 */
	private static void unregister() {
		if (g_pkcs11Provider != null) {
			String providerToRemove = SUNPKCS11 + PROVIDER_SUFFIX;
			Security.removeProvider(providerToRemove);
		}
	}

	/*
	 * dynamically add a provider. This avoids the necessity of adding this
	 * provider to the Java security library config file on every computer that
	 * uses this class.
	 * 
	 * Also loads needed Windows drivers library
	 * 
	 * Assumption: Running in a 32-bit or 64-bit Windows environment
	 * 
	 * @param : provider java config file
	 * 
	 * @param : above's drive location
	 */
	private void register(String p_conf, String p_drive) {
		g_pkcs11Provider = new sun.security.pkcs11.SunPKCS11(p_conf);
		try {
			@SuppressWarnings("unused")
			int addProvider = 0;
			addProvider = Security.addProvider(g_pkcs11Provider);
			String p1 = System.getProperty(SUN_ARCH_DATA_MODEL);
			String dllToLoad;
			String baseDll = p_drive + File.separator + HOME_DIR
					+ File.separator;
			// set according to 32 or 64 bit system
			if (p1.equals(BIT_32)) {
				dllToLoad = baseDll.concat(DLL_32);
			} else // if (p1.equals("64"))
			{
				dllToLoad = baseDll.concat(DLL_64);
			}
			System.load(dllToLoad);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/*
	 * Display information about CSPid, such as the algorithms supported. This
	 * list may be needed if there are problems on a specific workstation.
	 */
	private void printProviderInfo() {
		if (g_pkcs11Provider == null) {
			System.out.println("Provider not registered !!");
		} else {
			System.out.println("\n##### Provider Info #####");
			for (Iterator itr = g_pkcs11Provider.keySet().iterator(); itr
					.hasNext();) {
				String key = (String) itr.next();
				String value = (String) g_pkcs11Provider.get(key);
				System.out.println(" " + key + " = " + value);
			}
		}
	}

	/*
	 * List the certificates and private keys stored by CSPid. This method may
	 * be needed to quickly check certs in the p15 keystore
	 * 
	 * @throws exception
	 */
	private void list() throws Exception {
		String pin = ""; // set to empty, it will prompt for print
		System.out.println("\n##### List Certificates and Private Keys #####");
		KeyStore keyStore = KeyStore.getInstance(PKCS11_KEYSTORE);
		keyStore.load(null, pin.toCharArray());
		Enumeration aliasesEnum = keyStore.aliases();
		while (aliasesEnum.hasMoreElements()) {
			System.out
					.println("=========================================================");
			String alias = (String) aliasesEnum.nextElement();
			System.out.println("Alias : " + alias);
			X509Certificate x509Cert = (X509Certificate) keyStore
					.getCertificate(alias);
			System.out.println("Certificate : ");
			System.out.println(x509Cert);
			PrivateKey privateKey = (PrivateKey) keyStore.getKey(alias, null);
			System.out.println("Private Key : \n" + privateKey);
		}
	}

	/*
	 * get COI key info for encryption This method gets the COI public & private
	 * keys needed for encryption and decryption. For each COI to be accessed,
	 * there will have to be a separate function to get the required key pair
	 * 
	 * @param String alias
	 * 
	 * @throws Exception
	 */
	private void getCOIKeyPair(String p_CoiAlias) throws Exception {
		try {
			// a "" forces user to provide password
			String pin = "";
			System.out.println("\n##### Use Existing Key for #####");
			System.out.println("COI Alias : " + p_CoiAlias);
			KeyStore keyStore = KeyStore.getInstance(PKCS11_KEYSTORE);
			keyStore.load(null, pin.toCharArray());
			g_cert = keyStore.getCertificate(p_CoiAlias);
			if (g_cert == null) {
				throw new Exception("Key (" + p_CoiAlias + ") not found.");
			}
			g_coiPublicKey = g_cert.getPublicKey();
			g_coiPrivateKey = (PrivateKey) keyStore.getKey(p_CoiAlias, null);
			if (g_coiPrivateKey == null) {
				System.out.println("Private Key not found.");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.exit(-1);
		}
	}

	/*
	 * Generate a secret symmetric key using an AES algorithm. CSPid doesn't do
	 * key generation. Use Java key generator instead.
	 * 
	 * @param alg
	 * 
	 * @throws Exception
	 */
	private SecretKey genSecretKey(String p_alg) throws Exception {
		return KeyGenerator.getInstance(p_alg).generateKey();
	}

	/*
	 * Use the PKCS11 provider RSA/ECB/PKCS11Padding algorithm to encrypt/wrap
	 * the secret key using the COI public key
	 * 
	 * @param the PKCS11 cipher algorithm
	 * 
	 * @param the secret key
	 * 
	 * @return wrapped key as a byte array
	 */
	private byte[] encryptKey(String p_cipherAlg, SecretKey p_aesKey) {
		// convert secret key to a byte array
		byte[] secKey = p_aesKey.getEncoded();
		try {
			Cipher cipher = Cipher.getInstance(p_cipherAlg, g_pkcs11Provider);
			cipher.init(Cipher.ENCRYPT_MODE, g_coiPublicKey);
			cipher.update(secKey);
			byte[] cipherText;
			cipherText = cipher.doFinal();
			return cipherText;
		} catch (InvalidKeyException e) {
			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		} catch (NoSuchPaddingException e) {
			e.printStackTrace();
		} catch (IllegalBlockSizeException e) {
			e.printStackTrace();
		} catch (BadPaddingException e) {
			e.printStackTrace();
		}

		return null;
	}

	/*
	 * Creates a new file containing the wrapped key, an encrypted text file
	 * using the wrapped key and a flag containing the length of the wrapped
	 * key. The method adds the wrapped key to the beginning of the file. Then
	 * reads in a text file, encrypts the text and adds it to the text file. And
	 * then finally adds the key length tag to the end of the file.
	 * 
	 * @param cipherText
	 * 
	 * @param aesAlgorithm
	 * 
	 * @param aesKey
	 * 
	 * @param fileIn
	 * 
	 * @param fileOut
	 */
	public void encrypt(byte[] p_cipherText, String p_aesAlgorithm,
			SecretKey p_aesKey, FileInputStream p_fileIn,
			FileOutputStream p_fileOut) {
		String lgth = "";
		int len = p_cipherText.length;
		/*
		 * the key length tag(lgth) MUST be 3 characters (a preceding 0 is added
		 * if necessary). It MUST also include beginning & ending paragraph
		 * symbols so it can be read as a separate line during decryption
		 */
		if (len > 99) {
			lgth = "\n" + Integer.toString(len) + "\n";
		} else if (len < 10) {
			lgth = "\n00" + Integer.toString(len) + "\n";
		} else {
			lgth = "\n0" + Integer.toString(len) + "\n";
		}

		try {
			/*
			 * write wrapped key to file
			 */
			p_fileOut.write(p_cipherText, 0, len);
			/*
			 * encrypt text & write it to same file
			 */
			Cipher encryptedCipher = Cipher.getInstance(p_aesAlgorithm);
			encryptedCipher.init(Cipher.ENCRYPT_MODE, p_aesKey);
			byte[] buf = new byte[encryptedCipher.getBlockSize()];
			CipherOutputStream cOut = new CipherOutputStream(p_fileOut,
					encryptedCipher);
			int numRead = 0;
			while ((numRead = p_fileIn.read(buf)) != -1) {
				cOut.write(buf, 0, numRead);
			}
			/*
			 * This will force a read-to-end of file
			 */
			byte[] buf2 = new byte[128];
			cOut.write(buf2, 0, 128);
			/*
			 * write the wrapped key length tag to end of file
			 */
			byte[] b = lgth.getBytes();
			p_fileOut.write(b);
			buf = null;
			p_fileIn.close();
			cOut.close();
			p_fileOut.close();
		} catch (InvalidKeyException e) {
			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		} catch (NoSuchPaddingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/*
	 * This method accesses the encrypted file as a random access file so it can
	 * be read line by line looking for the key length tag. It converts the tag
	 * to an int and passes it along to the method that unwraps the key.
	 * 
	 * @param encrypted file
	 * 
	 * @return length of the wrapped key
	 */
	private int getKeyLength(File p_file) {
		int num = 0;
		try {
			String s;
			RandomAccessFile raf = new RandomAccessFile(p_file, "r");
			while ((s = raf.readLine()) != null) {
				if (!s.equals("") && s.length() > 2) {
					Character c = s.charAt(0);
					Character d = s.charAt(1);
					Character e = s.charAt(2);
					if (Character.isDigit(c) && Character.isDigit(d)
							&& Character.isDigit(e)) {
						String n = c.toString() + d.toString() + e.toString();
						num = Integer.parseInt(n);
						// debug
						System.out.println("Tag length = " + num);
					}
				}
			}
			raf.close();
		} catch (NumberFormatException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		return num;
	}

	/*
	 * This method reads the wrapped key from the encrypted file and sends it to
	 * the Document Access Servlet [DAS] to be unwrapped using the COI private
	 * key and the RSA algorithm. The DAS returns the unwrapped key which is
	 * passed to the decrypt method.
	 * 
	 * @param length of the wrapped key
	 * 
	 * @param the encrypted file
	 * 
	 * @param the RSA algorithm
	 * 
	 * @return unwrapped key as a byte array
	 */
	private byte[] decryptKey(int p_num, FileInputStream p_fileIn,
			String p_cipherAlg) {
		try {
			// convert original unwrapped key to byte array for comparison
			// purposes
			@SuppressWarnings("unused")
			int numRead = 0;
			byte[] cipherKey = new byte[p_num];
			numRead = p_fileIn.read(cipherKey);
			Cipher cipher = Cipher.getInstance(p_cipherAlg, g_pkcs11Provider);
			cipher.init(Cipher.DECRYPT_MODE, g_coiPrivateKey);
			cipher.update(cipherKey);
			byte[] plainText = cipher.doFinal();
			return plainText;
		} catch (InvalidKeyException e) {
			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		} catch (NoSuchPaddingException e) {
			e.printStackTrace();
		} catch (IllegalBlockSizeException e) {
			e.printStackTrace();
		} catch (BadPaddingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		return null;
	}

	/*
	 * This method converts the unwrapped key byte array to an AES key and uses
	 * it to decrypt the encrypted text. It stores the decrypted text in a file
	 * in the DECRYPT subdirectory.
	 * 
	 * @param unwrapped key as byte array
	 * 
	 * @param aesAlgorithm for encryption
	 * 
	 * @param the encrypted file
	 * 
	 * @param the decrypted file
	 */
	public void decrypt(byte[] p_unwrappedKey, String p_aesAlg,
			FileInputStream p_in, FileOutputStream p_out) throws IOException {
		System.out.println(" p_unwrapped_key len : " + p_unwrappedKey.length);
		System.out.println(" p_aesAlg        len : " + p_aesAlg.length());
		System.out.println(" p_in            len : " + p_in.available());
		try {
			SecretKeySpec secretKeySpec = new SecretKeySpec(p_unwrappedKey,
					AES_SECRET_KEY);
			Cipher decipher = Cipher.getInstance(p_aesAlg);
			decipher.init(Cipher.DECRYPT_MODE, secretKeySpec);
			System.out.println(" decipher.getBlockSize() len : "
					+ p_in.available());
			byte[] buf = new byte[decipher.getBlockSize()];
			CipherInputStream cin = new CipherInputStream(p_in, decipher);
			// bytes read in will be decrypted and stored in out file
			int numRead = 0;
			byte[] buf1 = new byte[256];
			numRead = cin.read(buf1);
			while ((numRead = cin.read(buf)) != -1) {
				p_out.write(buf, 0, numRead);
			}
			p_out.close();
			cin.close();
			p_in.close();
		} catch (InvalidKeyException e) {
			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		} catch (NoSuchPaddingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void printUsageAndExit() {
		System.out.println(USAGE);
		System.exit(-1);
	}
	/*
	 * The main method : - validates program invocation, inits vars - creates
	 * necessary directories - instantiates CSPID class - extracts algorithms -
	 * unregister the CSPID provider - register CSPID - display CSPID provider
	 * info - display certificates & private keys held by CSPID - get coi
	 * public/private key pair for the input coi_alias - IF encrypting, THEN -
	 * delete existing encrypted file if exists as code will append instead of
	 * replacing it - generate a secret key - encrypt the key - encrypt the file
	 * - ELSE {must be decrypting} - get the key out of the encrypted file -
	 * decrypt the key - decrypt the file - ENDIF
	 * 
	 * @param args
	 */
	public static void main(String[] p_args) {
		for (String s : p_args) {
			System.out.println(s);
		}
//		System.exit(0);

		// check for valid invocation - instruct user when incorrect & leave
		if (p_args == null || p_args.length != 4) {
			printUsageAndExit();
		}

		/*
		 * display invocation
		 */
		System.out.println("\nExecuting using the following :");
		System.out.println("\tCSPid " + p_args[0] + " " + p_args[1] + " "
				+ p_args[2] + " " + p_args[3]);

		// VALIDATE PARAMETER 1 of 4
		// mode has to = ENCRYPT or DECRYPT
		String mode = p_args[0];
		mode = mode.toUpperCase();
		if (!(mode.equals(ENCRYPT_MODE) || mode.equals(DECRYPT_MODE))) {
			System.out
					.println("\nERROR:\n\tVALIDATING that mode = ENCRYPT or DECRYPT: input mode = "
							+ mode + "\n");
			printUsageAndExit();
		}
		// set global encrypt/decrypt indicator
		g_bEncrypting = true;
		if (mode.equals(DECRYPT_MODE)) {
			g_bEncrypting = false;
		}

		// VALIDATE PARAMETER 2 of 4
		g_inFileName = p_args[1];
		// parameter 2 is an absolute file pathname
		// Required :
		// the file has to exist, can exist anywhere
		File f = new File(g_inFileName);
		boolean b1 = f.isFile();
		long l = f.length();
		if ((!b1) || (l == 0L)) {
			System.out
					.println("\nERROR:\n\tFile: "
							+ g_inFileName
							+ " is an invalid file. It may not exist OR it may be empty.\n");
			printUsageAndExit();
		}
		// Conditional :
		// ENCRYPTING
		// the \CSPID\ENCRYPT directory has to exist cuz
		// the encrypted file will be placed in this dir
		// DECRYPTING
		// the \CSPID\DECRYPT directory has to exist cuz
		// the decrypted file will be placed in this dir

		// create the sub-directories if they do not exist
		String baseDirectory = File.separator + HOME_DIR + File.separator;
		String targetDirectory;
		if (g_bEncrypting) {
			targetDirectory = baseDirectory.concat(ENCRYPT_DIR);
		} else {
			targetDirectory = baseDirectory.concat(DECRYPT_DIR);
		}
		boolean exists = new File(targetDirectory).exists();
		if (exists == false) {
			exists = new File(targetDirectory).mkdirs();
		}
		if (!exists) {
			System.out.println("\nERROR:\n\tOCCURRED CREATING : "
					+ targetDirectory + "\n");
			printUsageAndExit();
		}

		// if we are encrypting, the existing input file specified
		// will be encrypted into a new file; the new file will
		// be created in the target directory with a special suffix
		// if we are decrypting, the existing input file specified
		// MUST have the special suffix AND it will be decrypted
		// into a new file; the new file will be created in the
		// target directory with the special suffix removed
		String targetFile = "";
		String fn = f.getName();
		if (g_bEncrypting) {
			targetFile = targetDirectory + File.separator + fn + ENCRYPT_SUFFIX;
		} else // decrypting
		{
			// verify the filename has the special suffix
			if (!fn.endsWith(ENCRYPT_SUFFIX)) {
				System.out.println("\nERROR:\n\tINCORRECT FILENAME FOR: "
						+ g_inFileName + "\n");
				printUsageAndExit();
			}
			// remove the suffix from the input filenm to create target loc
			int length = fn.length() - (ENCRYPT_SUFFIX.length());
			String nfn = fn.substring(0, length);
			targetFile = targetDirectory + File.separator + nfn;
		}

		// VALIDATE PARAMETER 3 of 4
		g_inCoiAlias = p_args[2];
		// coi_alias has to be valid
		// validation can only occur after the Provider has been registered
		// since the alias format can be virtually anything, the best we can do
		// at this stage, is validate a parameter was provided , which was done
		// above

		// VALIDATE PARAMETER 4 of 4
		g_inDrive = p_args[3];
		// drive - the drive is used to find the location of the correct
		// dll file to load - which file to use and the actual
		// loading happens after the Provider is registered, again,
		// the best we can do at this point is verify that the
		// "'g_inDrive':\CSPID" location exists - it will be
		// up to the user to populate this folder with the
		// correct library files - as indicated in the install instructions
		String dllLoc = g_inDrive + File.separator + HOME_DIR;
		File d = new File(dllLoc);
		if (!d.isDirectory()) {
			System.out
					.println("\nERROR:\n\tPath "
							+ dllLoc
							+ " does NOT point to an existing CSPID dll folder location.\n");
			printUsageAndExit();
		}

		/*
		 * if we get here, we have valid program invocation
		 */
		System.out.println("\n##### CORRECT INVOCATION #####");
		System.out.println("Executing using the following values :");
		System.out.println("\tmode : "
				+ (g_bEncrypting ? "ENCRYPT" : "DECRYPT"));
		System.out.println("\tpath : " + g_inFileName);
		System.out.println("\talias: " + g_inCoiAlias);
		System.out.println("\tdrive: " + g_inDrive);

		// create a new instance of the class, open the properties file
		// extract the algorithms from the properties file
		CSPid cs = new CSPid();
		Properties props = null;
		props = cs.getProps();
		String aesAlgo = props.getProperty(AES_ALGO_PROPERTY);
		String rsaAlgo = props.getProperty(RSA_ALGO_PROPERTY);

		// unregister CSPID the provider - to start fresh
		// register CSPID
		// [optional] display CSPID provider info
		// [optional] display certificates & private keys held by CSPID
		// get the public/private key info for the provided coi
		try {
			unregister();
			cs.register(g_conf, g_inDrive);
			// cs.printProviderInfo();
			// cs.list();
			cs.getCOIKeyPair(g_inCoiAlias);
			/*
			 * IF encrypting delete the existing encrypted file if it exists
			 * generate a secret key encrypt the key encrypt the file
			 */
			if (g_bEncrypting) {
				File file = new File(targetFile);
				if (file.exists()) {
					file.delete();
				}
				SecretKey aesKey = cs.genSecretKey(AES_SECRET_KEY);
				byte[] cipherText = cs.encryptKey(rsaAlgo, aesKey);
				cs.encrypt(cipherText, aesAlgo, aesKey, new FileInputStream(
						g_inFileName), new FileOutputStream(targetFile, true));
			} else {
				/*
				 * ELSE [DECRYPTING] get the key out of the encrypted file
				 * decrypt the key - use DAS to do decryption using
				 * coi_alias'private key decrypt the file
				 */
				int num = cs.getKeyLength(new File(g_inFileName));
				byte[] plainText = cs.decryptKey(num, new FileInputStream(
						g_inFileName), rsaAlgo);
				if (plainText != null) {
					cs.decrypt(plainText, aesAlgo, new FileInputStream(
							g_inFileName), new FileOutputStream(targetFile));
				} else {
					System.out.println("\nERROR\n\t##### FAILURE #####");
					System.out
							.println("\tDAS cannot find valid key for provided coi_alias "
									+ g_inCoiAlias);
					System.exit(-1);
				}
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("\n##### SUCCESS #####");
		System.out.println("File has been successfully "
				+ (g_bEncrypting ? "ENCRYPTED" : "DECRYPTED"));
		System.out.println("File Location : " + targetFile + "\n");
	}
}
