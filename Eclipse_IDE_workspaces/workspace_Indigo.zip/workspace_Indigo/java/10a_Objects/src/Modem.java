public class Modem
{
    int speed;
    
    public void displaySpeed() {
        System.out.println("Speed is : " + speed);
    }
    
    public void disconnect(String method) {
        System.out.println("Disconnecting from : " + method);
    }
}
