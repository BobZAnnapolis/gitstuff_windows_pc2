class testModems
{
    /**
     * @param args
     */
    public static void main(String[] args)
    {
        // TODO Auto-generated method stub
        CableModem roadRunner = new CableModem();
        roadRunner.speed = 500000;
        System.out.println("Trying the cable modem...");
        roadRunner.displaySpeed();
        roadRunner.connect();
        roadRunner.disconnect(roadRunner.method);
        
        DslModem bellSouth = new DslModem();
        bellSouth.speed = 400000;
        System.out.println("\nTrying the DSL modem...");
        bellSouth.displaySpeed();
        bellSouth.connect();
        bellSouth.disconnect(bellSouth.method);
        
        AcousticModem acModem = new AcousticModem ();
        acModem.speed = 300;
        System.out.println("\nTrying the Acoustic modem...");
        acModem.displaySpeed();
        acModem.connect();
        acModem.disconnect(acModem.method);
    }
}
