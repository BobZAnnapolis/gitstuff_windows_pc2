public class Virus
{
    static int virusCount = 0;
    private int newSeconds;
    
    public int getNewSeconds()
    {
        return newSeconds;
    }

    public void setNewSeconds(int newSeconds)
    {
        if (( newSeconds >= 60) & ( newSeconds <=100))
        {
            this.newSeconds = newSeconds;
        }
    }

    public Virus()
    {
        virusCount++;
    }
    
    static int getVirusCount()
    {
        return virusCount;
    }
}
