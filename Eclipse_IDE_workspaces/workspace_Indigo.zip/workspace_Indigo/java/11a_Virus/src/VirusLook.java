public class VirusLook
{
    /**
     * @param args
     */
    public static void main(String[] args)
    {
        // TODO Auto-generated method stub
        if ( args.length > 0)
        {
            int numViruses = Integer.parseInt(args[0]);
            
            if ( numViruses > 0)
            {
                Virus[] virii = new Virus[numViruses];
                for ( int i = 0; i < numViruses; i ++)
                {
                    virii[i] = new Virus();
                    virii[i].setNewSeconds( i + 60);
                }
                System.out.println("there are " + Virus.getVirusCount() + " viruses.");
                for ( int i = 0; i < numViruses; i ++)
                {
                    System.out.println("virii[" + i + "].newSeonds = " + virii[i].getNewSeconds());
                }
            }
        }
        else
        {
            System.out.println("PROVIDE AN INPUT NUMBER !!");
        }
    }
}
