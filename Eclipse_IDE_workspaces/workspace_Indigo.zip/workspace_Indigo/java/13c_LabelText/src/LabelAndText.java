import java.awt.*;
import javax.swing.*;

public class LabelAndText extends JFrame {
    public LabelAndText() {
        super("Label and Text Field");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JLabel pageLabel = new JLabel("Web page address: ", JLabel.RIGHT);
        JTextField pageAddress = new JTextField(20);
        FlowLayout flo = new FlowLayout();
        setLayout(flo);
        add(pageLabel);
        add(pageAddress);
        pack();
        setVisible(true);
    }

    public static void main(String[] arguments) {
        LabelAndText latf = new LabelAndText();
    }
}