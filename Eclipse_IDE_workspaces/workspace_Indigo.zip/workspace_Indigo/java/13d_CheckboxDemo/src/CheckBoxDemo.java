import java.awt.*;
import javax.swing.*;

public class CheckBoxDemo extends JFrame {
    public CheckBoxDemo() {
        super("Enter Your Order");
        setSize(130, 240);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        JCheckBox frogLegs = new JCheckBox("Frog Leg Grande", true);
        JCheckBox fishTacos = new JCheckBox("Fish Taco Platter", false);
        JCheckBox emuNuggets = new JCheckBox("Emu Nuggets", false);
        JCheckBox jumboSize = new JCheckBox("Jumbo Size");
        
        FlowLayout flo = new FlowLayout();
        ButtonGroup meals = new ButtonGroup();
        meals.add(frogLegs);
        meals.add(fishTacos);
        meals.add(emuNuggets);
        
        setLayout(flo);
        
        add(frogLegs);
        add(fishTacos);
        add(emuNuggets);
        
        add(jumboSize);
        setVisible(true);
    }

    public static void main(String[] arguments) {
        CheckBoxDemo cbd = new CheckBoxDemo();
    }
}