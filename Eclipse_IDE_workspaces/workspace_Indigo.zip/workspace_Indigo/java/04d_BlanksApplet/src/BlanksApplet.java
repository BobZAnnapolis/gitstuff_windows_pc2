import java.awt.*;


public class BlanksApplet extends javax.swing.JApplet {

	String parm1;
	String parm2;
	String parm3;
	
	public void init() {
		parm1 = getParameter("adj1");
		parm2 = getParameter("adj2");
		parm3 = getParameter("adj3");
	}
	/**
	 * @param args
	 */
	public void paint(Graphics screen) {
		// TODO Auto-generated method stub
		screen.drawString( "The " + parm1 
		          + " " + parm2 + " fox "
		          + " jumped over the " 
		          + parm3 + " dog.", 5, 50
				  );
	}

}
