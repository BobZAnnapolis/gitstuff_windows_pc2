import java.util.Collections;
import java.util.Vector;


public class StringLister {
	
	String[] names = { "Spanky",
					   "Alfalfa",
					   "Buckwheat",
					   "Darla",
					   "Stymie",
					   "Marianne",
					   "Scotty",
					   "Tommy",
					   "Chubby"
					   };
	
	public StringLister( String[] moreNames) {
		// create the var to hold a varying # of strings
		Vector<String> list = new Vector<String>();
		for ( int i = 0; i < names.length; i++) {
			list.add(names[i]);
		}		
		// init the vector with more names from another source
		for ( int i = 0; i < moreNames.length; i++) {
			list.add(moreNames[i]);
		}		
		// use built-in class to sort them
		Collections.sort( list);
		// display the sorted list
		for ( String name : list) {
			System.out.println( name);
		}
	} // end StringLister

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringLister lister = new StringLister(args);
	}
}
