import java.io.*;
public class DirectoryListing {

	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		File dirListing = new File("C:\\");
		File[] dirNames = dirListing.listFiles();
		for ( int i = 0; i < dirNames.length; i++)
		{
			System.out.println(dirNames[i].getAbsolutePath());
		}
	}
}
