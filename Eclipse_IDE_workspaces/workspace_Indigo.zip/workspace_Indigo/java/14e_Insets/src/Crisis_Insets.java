import java.awt.*;
import javax.swing.*;

public class Crisis_Insets extends JFrame {
    JButton panicButton = new JButton("Panic");
    JButton dontPanicButton = new JButton("Don't Panic");
    JButton blameButton = new JButton("Blame Others");
    JButton mediaButton = new JButton("Notify the Media");
    JButton saveButton = new JButton("Save Yourself");

    public Insets getInsets() {
    	Insets squeeze = new Insets(50,15,10,15);
    	return squeeze;
    }
    
    public Crisis_Insets() {
        super("BorderInsets Crisis");
        setLocationRelativeTo(null); // center
        setSize(308, 128);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        BorderLayout border = new BorderLayout();
        setLayout(border);
        add(panicButton, BorderLayout.NORTH);
        add(dontPanicButton, BorderLayout.SOUTH);
        add(blameButton, BorderLayout.EAST);
        add(mediaButton, BorderLayout.WEST);
        add(saveButton, BorderLayout.CENTER);
        setVisible(true);
    }

    public static void main(String[] arguments) {
        Crisis_Insets cr = new Crisis_Insets();
    }
}