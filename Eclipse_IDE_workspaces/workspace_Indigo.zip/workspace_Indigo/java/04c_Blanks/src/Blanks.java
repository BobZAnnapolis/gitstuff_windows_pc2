
public class Blanks {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println( "The " + args[0] 
		          + " " + args[1] + " fox "
		          + " jumped over the " 
		          + args[2] + " fox "
				  );
	}

}
