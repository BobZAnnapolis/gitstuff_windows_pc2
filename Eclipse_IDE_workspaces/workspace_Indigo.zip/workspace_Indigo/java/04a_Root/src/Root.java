
public class Root {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int number = 225;
		System.out.println("The square root of "
				          + number 
				          + " is "
				          + Math.sqrt(number));
	}

}
