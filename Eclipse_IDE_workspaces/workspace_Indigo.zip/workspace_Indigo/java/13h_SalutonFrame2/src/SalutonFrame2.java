import javax.swing.*;
import java.awt.*;

public class SalutonFrame2 extends JFrame {
    public SalutonFrame2() {
        super();
        setSize(350, 100);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JLabel salutonLabel = new JLabel("Saluton mondo!");
        FlowLayout flo = new FlowLayout();
        setLayout(flo);
        add(salutonLabel);
        setVisible(true);
    }

    public static void main(String[] arguments) {
        SalutonFrame2 sal = new SalutonFrame2();
    }
}