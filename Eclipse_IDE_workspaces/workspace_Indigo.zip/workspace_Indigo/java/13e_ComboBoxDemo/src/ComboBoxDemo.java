import java.awt.*;
import javax.swing.*;

public class ComboBoxDemo extends JFrame {
    public ComboBoxDemo() {
        super("Select Your Profession");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JComboBox profession = new JComboBox();
        FlowLayout flo = new FlowLayout();
        profession.addItem("Butcher");
        profession.addItem("Baker");
        profession.addItem("Candlestick maker");
        profession.addItem("Fletcher");
        profession.addItem("Fighter");
        profession.addItem("Technical writer");
        setLayout(flo);
        add(profession);
        pack();
        setVisible(true);
    }

    public static void main(String[] arguments) {
        ComboBoxDemo cbd = new ComboBoxDemo();
    }
}