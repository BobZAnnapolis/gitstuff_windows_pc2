
class forLoop {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// display the numbers evenly divisible by 12 between 0 <+ 1000
		int count = 1;
		for (int dex = 0; dex < 1000; dex++)
		{
			if ( (dex % 12) == 0)
			{
				System.out.println(count + ": " + dex);
				count++;
			}
		}
	}
}
