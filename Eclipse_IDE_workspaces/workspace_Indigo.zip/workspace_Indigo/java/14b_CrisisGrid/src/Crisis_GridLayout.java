import java.awt.*;
import javax.swing.*;

public class Crisis_GridLayout extends JFrame {
    JButton panicButton = new JButton("Panic");
    JButton dontPanicButton = new JButton("Don't Panic");
    JButton blameButton = new JButton("Blame Others");
    JButton mediaButton = new JButton("Notify the Media");
    JButton saveButton = new JButton("Save Yourself");

    public Crisis_GridLayout() {
        super("GridLayout Crisis");
        setLocationRelativeTo(null); // center
        setSize(308, 128);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        GridLayout grid = new GridLayout(2,3);
        setLayout(grid);
        add(panicButton);
        add(dontPanicButton);
        add(blameButton);
        add(mediaButton);
        add(saveButton);
        setVisible(true);
    }

    public static void main(String[] arguments) {
        Crisis_GridLayout cr = new Crisis_GridLayout();
    }
}