import java.io.*;
import java.io.FileOutputStream;

public class ReadConsole {
    public static String readLine() {
        StringBuffer response = new StringBuffer();
        try {
            BufferedInputStream bin = new
                BufferedInputStream(System.in);
            int in = 0;
            char inChar;
            do {
                in = bin.read();
                inChar = (char) in;
                if (in != -1) {
                    response.append(inChar);
                }             
            } while ((in != -1) & (inChar != '\n'));
            bin.close();
            return response.toString();
        } catch (IOException e) {
            System.out.println("Exception: " + e.getMessage());
            return null;
        }
    }

    public static void main(String[] arguments) {
        System.out.print("You are standing at the end of the road ");
        System.out.print("before a small brick building.\nAround you ");
        System.out.print("is a forest.\nA small stream flows out of ");
        System.out.println("the building and down a gully.\n");
        System.out.print("> ");
        String input = ReadConsole.readLine();
        System.out.println("That's not a verb I recognize.\n");
        
        System.out.println("\ncreating a new file in c:\\temp and writing into it\n");
        File datF = new File("C:\\temp\\foo.dat");
        try
        {
            FileOutputStream datStream = new FileOutputStream(datF, true);
            byte[] data = new byte[]{5,12,4,13,3,15,2,17,1,18};
            datStream.write( data, 5, 5);
            datStream.close();
        }
        catch ( FileNotFoundException e) {        	
        }        
        catch ( IOException e) {        	
        }        
    }
}