import java.io.*;
import nu.xom.*;		// 3rd party library to read,write,parse XML files  

public class PropertyFileReader {
    String comment;
    String username;
    String browser;
    boolean showEmail;
   
    public PropertyFileReader() throws ParsingException, IOException {
        // get the XML document
        File propFile = new File("\\temp\\properties.xml");
        Builder builder = new Builder();
        Document doc = builder.build(propFile);
        // get the root element, <properties>
        Element root = doc.getRootElement();
        // get the <comment> element and store it in a variable
        Element commentElement = root.getFirstChildElement("comment");
        comment = commentElement.getValue();
        // get the <entry> elements
        Elements entries = root.getChildElements("entry");
        for (int current = 0; current < entries.size(); current++) {
            // get current <entry>
            Element entry = entries.get(current);
            // get entry's key attribute
            Attribute key = entry.getAttribute("key");
            String keyValue = key.getValue();
            // store attribute value in the proper variable
            if (keyValue.equals("username")) {
                username = entry.getValue();
            }
            if (keyValue.equals("browser")) {
                browser = entry.getValue();
            }
            if (keyValue.equals("showEmail")) {
                String emailValue = entry.getValue();
                if (emailValue.equals("yes")) {
                    showEmail = true;
                } else {
                    showEmail = false;
                }
            }
        }
    }
    
    public void showProperties() {
        System.out.println("\nProperties\n");
        System.out.println("Comment: " + comment);
        System.out.println("Username: " + username);
        System.out.println("Browser: " + browser);
        System.out.println("Show Email: " + showEmail);
    }
    
    public static void main(String[] arguments) {
    	System.out.println("\nNeed the properties.xml file from ch21a and the downloaded XOM jar file.");
    	System.out.println("Copy jar file into java or server lib and edit project properties to add an external library\n");
        try {
            PropertyFileReader reader = new PropertyFileReader();
            reader.showProperties();
        } catch (Exception exception) {
            System.out.println("Error: " + exception.getMessage());
        }
    }
}