import java.io.*;
import java.util.*;

public class TagCleaner {

    public static void main(String[] arguments) {
    	System.out.println("\nMove TagCLeaner.properties & test.html to \\temp dir & re-run.\n");
        TagCleaner cleaner = new TagCleaner("\\temp\\test.html");
    }
    
    public TagCleaner(String filename) {
        try {
            // load configuration properties
            File propFile = new File("\\temp\\TagCleaner.properties");
            FileInputStream propStream = new FileInputStream(propFile);
            Properties props = new Properties();
            props.load(propStream);
            String caseProperty = props.getProperty("case");
            String hideOutput = props.getProperty("hideOutput");
            // set up file input and output
            File file = new File(filename);
            FileInputStream in = new FileInputStream(file);
            File clean = new File(filename + ".clean");
            FileOutputStream out = new FileOutputStream(clean);
            boolean eof = false;
            boolean inTag = false;
            boolean inQuote = false;
            if (hideOutput.equals("false")) {
                System.out.print("Creating file ... ");
            }
            while (!eof) {
                int input = in.read();
                if (input == -1) {
                    eof = true;
                    continue;
                }
                // look for quote characters
                if (input == '"') {
                    if (inQuote != true) {
                        inQuote = true;
                    } else {
                        inQuote = false;
                    }
                }
                // look for tag opening
                if (input == '<') {
                    inTag = true;
                }
                // look for tag closing
                if (input == '>') {
                    inTag = false;
                    inQuote = false;
                }
                if ((!inTag) | (inQuote)) {
                    out.write((char)input);
                } else {
                    if (caseProperty.equals("lower")) {
                        out.write(Character.toLowerCase((char)input));
                    } else {
                        out.write(Character.toUpperCase((char)input));
                    }
                }
            }
            in.close();
            out.close();
            if (hideOutput.equals("false")) {
                System.out.println("done");
            }
        } catch (Exception e) {
            System.out.println("error\n\n" + e.toString());
        }
    }
}