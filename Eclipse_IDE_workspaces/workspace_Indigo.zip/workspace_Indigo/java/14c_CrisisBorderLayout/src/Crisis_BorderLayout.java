import java.awt.*;
import javax.swing.*;

public class Crisis_BorderLayout extends JFrame {
    JButton panicButton = new JButton("Panic");
    JButton dontPanicButton = new JButton("Don't Panic");
    JButton blameButton = new JButton("Blame Others");
    JButton mediaButton = new JButton("Notify the Media");
    JButton saveButton = new JButton("Save Yourself");

    public Crisis_BorderLayout() {
        super("BorderLayout Crisis");
        setLocationRelativeTo(null); // center
        setSize(308, 128);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        BorderLayout border = new BorderLayout();
        setLayout(border);
        add(panicButton, BorderLayout.NORTH);
        add(dontPanicButton, BorderLayout.SOUTH);
        add(blameButton, BorderLayout.EAST);
        add(mediaButton, BorderLayout.WEST);
        add(saveButton, BorderLayout.CENTER);
        setVisible(true);
    }

    public static void main(String[] arguments) {
        Crisis_BorderLayout cr = new Crisis_BorderLayout();
    }
}