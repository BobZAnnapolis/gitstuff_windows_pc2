public class convertFloat
{
    /**
     * @param args
     */
    public static void main(String[] args)
    {
        // TODO Auto-generated method stub
    	if ( args.length > 0)
    	{
            float float1 = Float.parseFloat(args[0]);
            System.out.println("float float1 = " + float1);
            Float newFloat = new Float(float1);
            System.out.println("Float newFloat = " + newFloat.floatValue());
            int intFloat = newFloat.intValue();
            System.out.println("int intFloat = " + intFloat);
    	}
    	else
    	{
            System.out.println("PROVIDE A FLOAT PARAMETER !!!");
    	}
    }
}
