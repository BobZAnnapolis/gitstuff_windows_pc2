class Saluton {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String gr = "Saluton Mondo !! {esperanto}";
		System.out.println( gr);
		
		gr = "bonjour monde {french}";
		System.out.println( gr);
		
		gr = "ciao mondo {italian}";
		System.out.println( gr);
		
		gr = "ol�! mundo {portuguese}";
		System.out.println( gr);
		
	}

}
