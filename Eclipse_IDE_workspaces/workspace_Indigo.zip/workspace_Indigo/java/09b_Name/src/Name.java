import java.util.Arrays;


class Name {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[] names = { "Peter", "Patricia", "Hunter", "Sarah",
				           "Gabe", "Gina", "Rob", "John", "Zoey", "Tammy",
				           "Robert", "Sean", "Paschal", "Kathy", "Neleh", "Vecepia"};
		System.out.println("The original order :");
		for ( int i = 0; i < names.length; i++)
		{
			System.out.print( names[i] + " ");
			if ((i % 10) == 0)
			{
				System.out.println(" ");
			}
		}
		System.out.println(" ");
		Arrays.sort(names);
		System.out.println("The new order :");
		for ( int i = 0; i < names.length; i++)
		{
			System.out.print( names[i] + " ");
			if ((i % 10) == 0)
			{
				System.out.println(" ");
			}
		}
	}
}
