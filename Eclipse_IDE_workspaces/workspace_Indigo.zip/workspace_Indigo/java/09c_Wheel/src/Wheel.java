
class Wheel {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// phrases to count
		System.out.println("init'ing the phrases array");
		String[] phrase = { "A STITCH IN TIME SAVES NINE",
							"DON'T EAT YELLOW SNOW",
							"JUST DO IT",
							"QUIZ ME",
							"FOXY",
							"EVERY GOOD BOY DOES FINE",
							"I WANT MY MTV",
							"HOW 'BOUT THEM COWBOYS",
							"PLAY IT AGAIN, SAM",
							"FROSTY THE SNOWMAN",
							"HELLO, KITTY",
							"ONE MORE FOR THE ROAD",
							"HOME FIELD ADVANTAGE",
							"VALENTINE'S DAY MASSACRE",
							"GROVER CLEVELAND OHIO",
							"WONDERFUL WORLD OF DISNEY",
							"COAL MINER'S DAUGHTER",
							"WILL IT PLAY IN PEORIA",
							"THAT'S WHAT SHE SAID"
							};
		// count each letter - just do caps
		System.out.println("init'ing the letter count array");
		int[] letterCount = new int[26];
		
		// parse each phrase & store each letter counts
		System.out.println("starting to parse the phrases");
		for ( int count = 0; count < phrase.length; count++)
		{
			String current = phrase[count];
			char[] letters = current.toCharArray();
			for ( int count2 = 0; count2 < letters.length; count2++)
			{
				char lett = letters[count2];
				if ( (lett >= 'A') & (lett <= 'Z'))
				{
					letterCount[lett - 'A']++;
				}
			}
		} // parse the phrases
		System.out.println("stopped parsing the phrases");
		
		// print out character counts
		System.out.println("starting to display letter counts");
		for ( char count = 'A'; count <= 'Z'; count++)
		{
			System.out.println(count + " : " + letterCount[ count - 'A']);
		}
		System.out.println("stopped displaying letter counts");
	}
}
