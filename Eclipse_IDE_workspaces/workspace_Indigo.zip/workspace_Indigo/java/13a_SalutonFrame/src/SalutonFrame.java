import javax.swing.JFrame;


public class SalutonFrame extends JFrame {

	public SalutonFrame() {
		super();
		setTitle("Saluton mondo Deux !");
		setSize(350,100);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		SalutonFrame sal = new SalutonFrame();
	}

}
