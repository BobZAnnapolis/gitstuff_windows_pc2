// import java.awt.*;
import javax.swing.*;

public class Crisis_BoxLayout extends JFrame {
    JButton panicButton = new JButton("Panic");
    JButton dontPanicButton = new JButton("Don't Panic");
    JButton blameButton = new JButton("Blame Others");
    JButton mediaButton = new JButton("Notify the Media");
    JButton saveButton = new JButton("Save Yourself");

    public Crisis_BoxLayout() {
        super("BoxLayout Crisis");
        setLocationRelativeTo(null); // center
        setSize(308, 228);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JPanel pane = new JPanel();
        BoxLayout box = new BoxLayout( pane, BoxLayout.Y_AXIS);
        pane.setLayout(box);
        pane.add(panicButton);
        pane.add(dontPanicButton);
        pane.add(blameButton);
        pane.add(mediaButton);
        pane.add(saveButton);
        add(pane);
        setVisible(true);
    }

    public static void main(String[] arguments) {
        Crisis_BoxLayout cr = new Crisis_BoxLayout();
    }
}