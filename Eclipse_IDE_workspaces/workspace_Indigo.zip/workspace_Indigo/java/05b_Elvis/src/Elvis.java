
class Elvis {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int x, y;
		int weight = 250;		
		System.out.println("Elvis weighs " + weight);
		System.out.println("Elvis visits all-you-can-eat rib joint !!");
		System.out.println("Elvis throws Thanksgiving luau.");
		System.out.println(" ");
		
		weight = weight + 10;		
		System.out.println("Elvis now weighs " + weight);
		System.out.println("Elvis discovers aerobics.");
		System.out.println(" ");

		weight = weight - 15;		
		System.out.println("Elvis now weighs " + weight);
		System.out.println("Elvis falls into washing machine during rinse cycle.");
		System.out.println(" ");

		weight = weight / 3;		
		System.out.println("Elvis now weighs " + weight);
		System.out.println("Ooops ! Elvis clones himself 12 times.");
		System.out.println(" ");

		weight = weight + (weight * 12);
		System.out.println("The 13 Elvii now weigh " + weight);
		System.out.println(" ");

		x = 10;
		y = 11;
		System.out.println( "(" + x + " * " + x + ')' + " + " + '(' + y +  " * " + y + ')' + " = " + ( (x*x) + (y*y)));
		System.out.println(" ");
	}

}
