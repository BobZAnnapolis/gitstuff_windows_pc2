import java.awt.*;
class TryPoints {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Point obj1 = new Point(11,22);
		Point3D obj2 = new Point3D(7,6,4);
		
		System.out.println("The 2D point is located at (" + obj1.x + ", " + obj1.y + ")");
		System.out.println("\tIt's being moved to (4,13)");
		obj1.move(4,13);
		System.out.println("The 2D point is now at (" + obj1.x + ", " + obj1.y + ")");
		System.out.println("It's being moved -10 units on both the x and y axis");
		obj1.translate(-10,-10);
		System.out.println("The 2D point ends up at (" + obj1.x + ", " + obj1.y + ")\n");
		
		System.out.println("The 3D point is located at (" + obj2.x + ", " + obj2.y + ", " + obj2.z + ")");
		System.out.println("\tIt's being moved to (10,22,71)");
		obj2.Move(10,22,71);
		System.out.println("The 3D point is now at (" + obj2.x + ", " + obj2.y + ", " + obj2.z + ")");
		System.out.println("It's being moved -20 units on both the x, y & z axis");
		obj2.Translate(-20,-20,-20);
		System.out.println("The 3D point ends up at (" + obj2.x + ", " + obj2.y + ", " + obj2.z + ")\n");
		
	}

}
