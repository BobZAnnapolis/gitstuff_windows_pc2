import java.awt.*;


public class Point3D extends Point {
	public int z;
	
	public Point3D(int x, int y, int z) {
		super(x,y);
		this.z = z;
	}
	
	public void Move( int x, int y, int z) {
		this.z = z;
		super.move(x, y);
	}
	
	public void Translate( int x, int y, int z) {
		this.z += z;
		super.translate(x, y);
	}
	
} // end public class Point3D
