import java.awt.*;
import javax.swing.*;

public class Crisis extends JFrame {
    JButton panicButton = new JButton("Panic");
    JButton dontPanicButton = new JButton("Don't Panic");
    JButton blameButton = new JButton("Blame Others");
    JButton mediaButton = new JButton("Notify the Media");
    JButton saveButton = new JButton("Save Yourself");

    public Crisis() {
        super("FlowLayout Crisis");
        setLocationRelativeTo(null); // center
        setSize(308, 128);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        FlowLayout flo = new FlowLayout();
        setLayout(flo);
        add(panicButton);
        add(dontPanicButton);
        add(blameButton);
        add(mediaButton);
        add(saveButton);
        setVisible(true);
    }

    public static void main(String[] arguments) {
        Crisis cr = new Crisis();
    }
}