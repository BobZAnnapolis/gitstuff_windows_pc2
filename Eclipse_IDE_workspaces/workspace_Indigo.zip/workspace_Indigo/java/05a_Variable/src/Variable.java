
class Variable {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int tops;
		float gradePointAverage;
		char key = 'C';
		String productName = "Larvets";
	}

}
