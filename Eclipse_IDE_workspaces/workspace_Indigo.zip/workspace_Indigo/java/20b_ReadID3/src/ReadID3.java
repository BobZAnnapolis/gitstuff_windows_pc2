import java.io.*;

public class ReadID3 {
    public static void main(String[] arguments) {
    	String[] mp3s = { "C:\\temp\\Kalimba.mp3"
    			  , "C:\\temp\\Maid with the Flaxen Hair.mp3"
    			  , "C:\\temp\\SLeep Away.mp3"};

    	for ( int i = 0; i < mp3s.length; i++)
    	{
    	       try {
//     	          File song = new File(arguments[0]);
     	          	File song = new File(mp3s[i]);
    	            FileInputStream file = new FileInputStream(song);
    	            int size = (int)song.length();
    	            file.skip(size - 128);
    	            byte[] last128 = new byte[128];
    	            file.read(last128);
    	            String id3 = new String(last128);
    	            String tag = id3.substring(0, 3);
    	            if (tag.equals("TAG")) {
    	                System.out.println("Title: " + id3.substring(3, 32));
    	                System.out.println("Artist: " + id3.substring(33, 62));
    	                System.out.println("Album: " + id3.substring(63, 91));
    	                System.out.println("Year: " + id3.substring(93, 97));
    	                System.out.println(" ");
    	            } else {
    	                System.out.println(arguments[0] + " does not contain"
    	                     + " ID3 info.");
    	            }
    	            file.close();
    	        } catch (Exception e) {
    	            System.out.println("Error -- " + e.toString());
    	        }
    	    	}
    }
}