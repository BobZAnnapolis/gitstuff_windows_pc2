import java.util.Calendar;
import java.util.GregorianCalendar;


class Repeat {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// loop a million times or for 1 minute
		String sentence = "Thorium-230 is not a toy !.";
		int count = 10;
		Calendar start = Calendar.getInstance();
		int startMinute = start.get(Calendar.MINUTE);
		int startSecond = start.get(Calendar.SECOND);
		start.roll(Calendar.MINUTE, true);
		int nextMinute = start.get(Calendar.MINUTE);
		int nextSecond = start.get(Calendar.SECOND);
		while ( count < 1000000)
		{
			System.out.println( sentence);
			GregorianCalendar now = new GregorianCalendar();
			if ( now.get(Calendar.MINUTE) >= nextMinute)
			{
				if ( now.get(Calendar.SECOND) >= nextSecond)
				{
					break;
				}
			}
			count++;
		}
		System.out.println("\nI wrote the sentence " + count + " times.");
		System.out.println("I have learned my lesson.");
	}
}
