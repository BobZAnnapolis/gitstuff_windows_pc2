
class Nines {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// display the 1st 200 multiples of 9
		for (int dex = 1; dex <= 200; dex++)
		{
			int multiple = 9 * dex;
			System.out.print(multiple + " ");
			// add some spacing
			if ( (dex % 10) == 0)
			{
				System.out.println(" ");
			}
		}

	}

}
