package ch2;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import coreservlets.ServletUtilities;

/** Servlet that attempts to give each user a unique
 *  user ID. However, because it fails to synchronize
 *  access to the nextID field, it suffers from race
 *  conditions: two users could get the same ID.
 *  <P>
 *  Taken from Core Servlets and JavaServer Pages 2nd Edition
 *  from Prentice Hall and Sun Microsystems Press,
 *  http://www.coreservlets.com/.
 *  &copy; 2003 Marty Hall; may be freely used or adapted.
 */

public class UserIDs extends HttpServlet {
  private int nextID = 0;
  
  public void doGet(HttpServletRequest request,
                    HttpServletResponse response)
      throws ServletException, IOException {
	  System.out.println("doGet() called");
    response.setContentType("text/html");
    PrintWriter out = response.getWriter();
    String title = "Your ID";
    out.println(ServletUtilities.headWithTitle(title));
    out.println("<H1 ALIGN=CENTER>" + title + "</H1>\n" +
                "<CENTER>\n" +
                "<H1>" + title + "</H1>\n");
	  System.out.println("\tentering synchronized block for user " + nextID);
    synchronized(this)
    {
        String id = "User-ID-" + nextID;
        out.println("<H2>" + id + "</H2>");
        nextID = nextID + 1;
    }
    out.println("</BODY></HTML>");
  }
}
