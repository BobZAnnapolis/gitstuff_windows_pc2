package cspid;
/**************************************************************************************
 * 
 * CSPid.java
 * @author Azi Siner / Robert John Zawislak
 * Modification History
 * 		OCT 11, 2012	rjz		Handed over to me, project personnel change
 * 								(1) as of this date, discovered that we have to 
 * 									use the 32-bit version of the Windows Java 
 * 									JDK/JRE & IDEs - PKCS11 jars not avlbl in 
 * 									64-bit version yet :-(
 * 								(2) changed original version member naming 
 * 									conventions a little to more easily identify
 * 									local, global & parameters
 * 		JUN 07, 2012	as		Initial Version
 * 
 * *************************************************************************************
 *
 * This class contains code to :
 * 	1) dynamically register and unregister a CSPid PKCS11 provider
 *  2) list the CSPid provider services, algorithms, certs & keys
 *  3) get specific key pairs for encryption & decryption
 *  4) generate an AES Secret key
 *  5) encrypt (wrap) the Secret key using the COI public key
 *  6) create a file and add the wrapped Secret key; encrypt a document and
 *            add it to the file, then add a tag containing the length of the key
 *  7) send the wrapped key to the Document Access Server (DAS) while
 *          send back the unwrapped key
 *  8) use the returned key to decrypt the encrypted COI document
 *  
 *  For this code to work, the wrapped key MUST be the first item in
 *  the file. Next comes the encrypted document. The tag must be the
 *  LAST item in the file.
 *  
 *  This class can be broken up into two {or more} classes, one for
 *  encryption and one for decryption.
 *  
 * *************************************************************************************/

import java.io.*;
import java.security.*;
import java.security.cert.*;
import java.security.Provider.*;
import java.security.spec.*;
import java.util.*;
import javax.crypto.*;
import javax.crypto.spec.*;

import sun.security.

/* *********************************************************************************** */

public class CSPid {
	
	java.security.cert.Certificate	g_cert = null;
	PrivateKey						g_coiPrivateKey;
	PublicKey 						g_coiPublicKey;
	public static Provider 			g_pkcs11Provider = null;
	public static String 			g_conf = "\\Program Files (x86)\\CSPid\\cspid.dll";
	public static String 			PROVIDER_SUFFIX = "CSPid";
	public static String			USAGE = "\n##### INCORRECT INVOCATION #####\nusage: CSPid mode full_path_to_file coi_alias drive";

	public CSPid() {
		; // tbd
	}

	/**
	 * getProperties
	 * utility function allows class to read a Properties file
	 * @return: properties list
	 */
	public Properties getProps() {
		Properties props = new Properties();
		try {
			props.load(new FileInputStream("\\CSPID\\CSPid.properties"));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return props;
	}
	
	/**
	 * static method to dynamically remove CSPid as a provider
	 */
	private static void unregister() {
		if (g_pkcs11Provider != null) {
			Security.removeProvider("SunPKCS11-" + PROVIDER_SUFFIX);
		}
	}
	
	/**
	 * dynamically add CSPid as provider. This avoids the necessity of adding
	 * this provider to the Java security library config file on every computer
	 * that uses this class. Also loads needed Windows drivers library
	 * @param : provider java config file
	 * @param : above's drive location
	 */
	private void register( String p_conf
						 , String p_drive
						 ) 
	{
		g_pkcs11Provider = new sun.security.pkcs11.SunPKCS11(p_conf);
		try {
			Security.addProvider(g_pkcs11Provider);
			String p1 = System.getProperty("sun.arch.data.model");
			// determine if running 32 or 64 bit system
			if (p1.equals("32")) {
				System.load(p_drive + "\\CSPID\\CDK7060S.dll");
			}
			else if (p1.equals("64")){
				System.load(p_drive + "\\CSPID\\CDK7060Sx64.dll");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * Display information about CSPid such as the algorithms supported.
	 * This list may be needed if there are problems on a specific workstation. 
	 */
	private void printProviderInfo() 
	{
		if (g_pkcs11Provider == null) {
			System.out.println("Provider not registered !!");
		}
		else {
			System.out.println("\n##### Provider Info #####");
			for ( Iterator itr = g_pkcs11Provider.keySet().iterator(); 
				  itr.hasNext(); ) 
			{
				String key = (String)itr.next();
				String value = (String)g_pkcs11Provider.get(key);
				System.out.println(" " + key + " = " + value);
			}
		}
	}

	/**
	 * List the certificates and private keys stored by CSPid.
	 * This method may be needed to quickly check certs in the p15 keystore
	 * @throws exception
	 */
	private void list() 
	throws Exception 
	{
		String pin = ""; // set to empty, it will prompt for print
		System.out.println("\n##### List Certificates and Private Keys #####");
		KeyStore keyStore = KeyStore.getInstance("PKCS11");
		keyStore.load(null, pin.toCharArray());
		Enumeration aliasesEnum = keyStore.aliases();
		while (aliasesEnum.hasMoreElements()) {
			System.out.println("=========================================================");
			String alias = (String)aliasesEnum.nextElement();
			System.out.println("Alias : " + alias);
			X509Certificate x509Cert = (X509Certificate)keyStore.getCertificate(alias);
			System.out.println("Certificate : ");
			System.out.println(x509Cert);
			PrivateKey privateKey = (PrivateKey)keyStore.getKey(alias, null);
			System.out.println("Private Key : \n" + privateKey);
		}
	}

	/**
	 * get COI key pair for encryption
	 * This method gets the COI public & private keys needed for encryption and decryption.
	 * For each COI to be accessed, there will have to be a separate function to get the required key pair
	 * @param String alias
	 * @throws Exception
	 */
	private void getCOIKeyPair(String p_alias) 
	throws Exception 
	{
		// force user to provide password
		String pin = "";
		System.out.println("\n##### Use Existing Key #####");
		System.out.println("Alias : " + p_alias);
		KeyStore keyStore = KeyStore.getInstance("PKCS11");
		keyStore.load(null, pin.toCharArray());
		g_cert = keyStore.getCertificate( p_alias);
		if (g_cert == null) {
			throw new Exception("Key (" + p_alias + ") not found.");
		}
		g_coiPublicKey = g_cert.getPublicKey();
		g_coiPrivateKey = (PrivateKey)keyStore.getKey(p_alias, null);
		if (g_coiPrivateKey == null) {
			System.out.println("Private Key not found.");
		}
	}
	
	/**
	 * Generate a secret symmetric key using an AES algorithm.
	 * CSPid doesn't do key generation.
	 * Use Java key generator instead.
	 * @param alg
	 * @throws Exception
	 */
	private SecretKey genSecretKey(String p_alg) 
	throws Exception {
		return KeyGenerator.getInstance( p_alg).generateKey();
	}
	
	/**
	 * Use the PKCS11 provider RSA/ECB/PKCS11Padding algorithm to
	 * encrypt/wrap the secret key using the COI public key
	 * @param the PKCS11 cipher algorithm
	 * @param the secret key
	 * @return wrapped key as a byte array
	 */
	private byte[] encryptKey( String p_cipherAlg
							 , SecretKey p_aesKey
							 ) 
	{
		// convert secret key to a byte array
		byte[] secKey = p_aesKey.getEncoded();
		try {
			Cipher cipher = Cipher.getInstance(p_cipherAlg, g_pkcs11Provider);
			cipher.init(Cipher.ENCRYPT_MODE, g_coiPublicKey);
			cipher.update(secKey);
			byte[] cipherText;
			cipherText = cipher.doFinal();
			return cipherText;
		} catch (InvalidKeyException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchPaddingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalBlockSizeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (BadPaddingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}

	/**
	 * Creates a new file containing the wrapped key, an encrypted text file 
	 * using the wrapped key and a flag containing the length of the
	 * wrapped key.
	 * The method adds the wrapped key to the beginning of the file.
	 * Then reads in a text file, encrypts the text and adds it to the text file.
	 * And then finally adds the key length tag to the end of the file.
	 * @param cipherText
	 * @param aesAlgorithm
	 * @param aesKey
	 * @param fileIn
	 * @param fileOut
	 */
	public void encrypt( byte[] p_cipherText
						, String p_aesAlgorithm
						, SecretKey p_aesKey
						, FileInputStream p_fileIn
						, FileOutputStream p_fileOut
						) {
		String lgth = "";
		int len = p_cipherText.length;
		/* 
		 * the key length tag(lgth) MUST be 3 characters (a preceding 0 is added
		 * if necessary). It MUST also include beginning & ending paragraph symbols
		 * so it can be read as a separate line during decryption
		 */
		if (len > 99) {
			lgth = "\n" + Integer.toString(len) + "\n";
		} else if (len < 10) {
			lgth = "\n00" + Integer.toString(len) + "\n";
		} else {
			lgth = "\n0" + Integer.toString(len) + "\n";
		}
		try {
			/*
			 * write wrapped key to file
			 */
			p_fileOut.write(p_cipherText, 0, len);
			/*
			 * encrypt text & write it to same file
			 */
			Cipher encryptedCipher = Cipher.getInstance(p_aesAlgorithm);
			encryptedCipher.init(Cipher.ENCRYPT_MODE, p_aesKey);
			byte[] buf = new byte[encryptedCipher.getBlockSize()];
			CipherOutputStream cOut = new CipherOutputStream(p_fileOut, encryptedCipher);
			int numRead = 0;
			while ((numRead = p_fileIn.read(buf)) != -1) {
				cOut.write(buf, 0, numRead);
			}
			/*
			 * This will force a read-to-end of file
			 */
			byte[] buf2 = new byte[128];
			cOut.write(buf2, 0, numRead);
			/*
			 * write the wrapped key length tag to end of file
			 */
			byte[] b = lgth.getBytes();
			p_fileOut.write(b);
			buf = null;
			p_fileIn.close();
			cOut.close();
			p_fileOut.close();
		} catch (InvalidKeyException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchPaddingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/*
	 * This method accesses the encrypted file as a random access file
	 * do it can be read line by line looking for the key length tag.
	 * It converts the tag to an int and passes it along to the method
	 * that unwraps the key.
	 * @param encrypted file
	 * @return length of the wrapped key
	 */
	private int getKeyLength(File p_file) {
		int num = 0;
		try {
			String s;
			RandomAccessFile raf = new RandomAccessFile(p_file, "r");
			while ((s = raf.readLine()) != null) {
				if (! s.equals("") && s.length() > 2) {
					Character c = s.charAt(0);
					Character d = s.charAt(1);
					Character e = s.charAt(2);
					if (Character.isDigit(c) && Character.isDigit(d) && Character.isDigit(e) ) {
						String n = c.toString() + d.toString() + e.toString();
						num = Integer.parseInt(n);
						// debug 
						System.out.println("Tag length = " + num);
					}
				}
			}
			raf.close();
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return num;
	}
	
	/**
	 * This method reads the wrapped key from the encrypted file and sends it to the
	 * Document Access Servlet [DAS] to be unwrapped using the COI private key and 
	 * the RSA algorithm. The DAS returns the unwrapped key which is passed to the
	 * decrypt method.
	 * 
	 *  @param length of the wrapped key
	 *  @param the encrypted file
	 *  @param the RSA algorithm
	 *  @return unwrapped key as a byte array
	 */
	private byte[] decryptKey( int p_num
							 , FileInputStream p_fileIn
							 , String p_cipherAlg
							 ) 
	{
		try {
			// convert original unwrapped key to byte array for comparison purposes
			int numRead = 0;
			byte[] cipherKey = new byte[p_num];
			numRead = p_fileIn.read(cipherKey);
			Cipher cipher = Cipher.getInstance(p_cipherAlg, g_pkcs11Provider);
			cipher.init(Cipher.DECRYPT_MODE, g_coiPrivateKey);
			cipher.update(cipherKey);
			byte[] plainText = cipher.doFinal();
			return plainText;
		} catch (InvalidKeyException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchPaddingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalBlockSizeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (BadPaddingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}

	/**
	 * This method converts the unwrapped key byte array to an AES key
	 * and uses it to decrypt the encrypted text. It stores the decrypted
	 * text in a file in the DECRYPT subdirectory.
	 * @param unwrapped key as byte array
	 * @param aesAlgorithm for encryption
	 * @param the encrypted file
	 * @param the decrypted file
	 */
	public void decrypt( byte[] plainText
					   , String aesAlg
					   , FileInputStream in
					   , FileOutputStream out
					   ) 
	{
		try {
			SecretKeySpec key = new SecretKeySpec(plainText, "AES");
			Cipher decipher = Cipher.getInstance(aesAlg);
			decipher.init(Cipher.DECRYPT_MODE, key);
			byte[] buf = new byte[decipher.getBlockSize()];
			CipherInputStream cin = new CipherInputStream(in,decipher);
			// bytes read in will be decrypted and stored in out file
			int numRead = 0;
			byte[] buf1 = new byte[256];
			numRead = cin.read(buf1);
			while ((numRead = cin.read(buf)) != -1) {
				out.write(buf, 0, numRead);
			}
			out.close();
			cin.close();
			in.close();
		} catch (InvalidKeyException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchPaddingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	static boolean bValidInputParms(String[] p_args) {
		boolean result = false;
	 	if ( p_args.length != 4) {
			System.out.println("\n##### INCORRECT INVOCATION #####");
			System.out.println("usage: CSPid mode full_path_to_file coi_alias drive");
				return result;
		} else {
			// validate parameter 1 of 4
			//		mode has to be ENCRYPT or DECRYPT
			String mode = p_args[0];
			mode = mode.toUpperCase();
			System.out.println("VALIDATING that mode = ENCRYPT or DECRYPT: input mode = " + mode);
			if ( ( ! mode.equals("ENCRYPT")) && ( ! mode.equals("DECRYPT")) ) {
				System.out.println(USAGE);
				System.out.println("mode = ENCRYPT or DECRYPT");
				return result;
			}			
			// validate parameter 2 of 4
			//		absolute_filepath - file has to exist
			
			// validate parameter 3 of 4
			//		coi_alias has to be valid
			
			// validate parameter 4 of 4
			//		drive - has to exist
			
		}
		return true;
	}
	
	
	static void report(String msg, boolean b)
	{
		System.out.println(msg + (b ? "success" : "failure"));
	}
	 
	/**
	* The main method creates 2 sub-directories, 1 for encrypted and 1 for 
	* decrypted files. 
	* It takes 4 command line arguments :
	* -		mode - ENCRYPT or DECRYPT
	*  -	the absolute path to the file to be either encrypted or decrypted
	*  -	the alias of the Community of Interest [COI] certificate
	*  -	drive letter
	*
	* @param args
	*/
	public static void main(String[] p_args) 
	{
		// check for valid invocation - instruct user when incorrect & leave
		
		if ( ! bValidInputParms(p_args)) {
			return;
		}

		System.out.println("\n##### CORRECT INVOCATION #####");
		System.out.println("Executing using the following values :");
		System.out.println("\tmode : " + p_args[0]);
		System.out.println("\tpath : " + p_args[1]);
		System.out.println("\talias: " + p_args[2]);
		System.out.println("\tdrive: " + p_args[3]);
			
		// create the sub-directories if they do not exist
		String mode = p_args[0];
		mode = mode.toUpperCase();
		boolean created = true;
		boolean exists = new File("C:\\CSPID\\ENCRYPT").exists();
		if ( ((exists == false) && (mode.equals("ENCRYPT"))) ) {
			created = new File("C:\\CSPID\\ENCRYPT").mkdir();
			report("Creating ENCRYPT directory : ", created);
		}
	
		exists = new File("\\CSPID\\DECRYPT").exists();
		if ( ((exists == false) && (mode.equals("DECRYPT"))) ) {
			created = new File("\\CSPID\\DECRYPT").mkdir();
			report("Creating DECRYPT directory : ", created);
		}
		String infile1 = p_args[1];
		File f = new File(p_args[1]);
		String fn = f.getName();
		String temp1 = "\\CSPID\\ENCRYPT\\" + fn + ".enc";
			
		// remove the .enc file suffix from the decrypted file
		int length = fn.length()-4;
		String nfn = fn.substring(0, length);
		String outfile1 = "\\CSPID\\DECRYPT\\" + nfn;
		
		/// set up other params
		String coiAlias = p_args[2];
		String drive = p_args[3];
		Properties props = null;

		// create a new instance of the class & access the properties file
		CSPid cs = new CSPid();
		props = cs.getProps();
			
		// extract the algorithms from the properties file
		String aesAlgo = props.getProperty("aesAlgo");
		String rsaAlgo = props.getProperty("rsaAlgo");

		// unregister CSPID the provider
		// register CSPID 
		// display CSPID provider info
		// display certificates & private keys held by CSPID
		// get coi public/private key pair
		try {
			unregister();
			cs.register(g_conf, drive);
			cs.printProviderInfo();
			cs.list();
			cs.getCOIKeyPair(coiAlias);
			/**
			 * IF encrypting
			 * 	delete existing encrypted file as code will append instead of replacing it
			 * 	generate a secret key
			 * 	encrypt the key
			 * 	encrypt the file
			 */
			if (mode.equals("ENCRYPT")) {
				File file = new File(temp1);
				if (file.exists()) {
					file.delete();
				}
				SecretKey aesKey = cs.genSecretKey("AES");
				byte[] cipherText = cs.encryptKey(rsaAlgo, aesKey);
				cs.encrypt( cipherText
						  , aesAlgo
						  , aesKey
						  , new FileInputStream(infile1)
						  , new FileOutputStream(temp1, true)
				          );
			} else {
			/** ELSE [DECRYPTING]
			 * 	get the key out of the encrypted file
			 * 	decrypt the key
			 * 	decrypt the file
			 */
				int num = cs.getKeyLength(new File(infile1));
				byte[] plainText = cs.decryptKey(num, new FileInputStream(infile1), rsaAlgo);
				cs.decrypt( plainText
						  , aesAlgo
						  , new FileInputStream(infile1)
						  , new FileOutputStream(outfile1)
				          );
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
